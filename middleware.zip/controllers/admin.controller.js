const Admin = require("../models/admin.model");
const User = require("../models/user.model");
const Support = require("../models/support.model");
const HostApplication = require("../models/host_application.model");
const cloudinary = require("../config/cloudinary");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const exceljs = require("exceljs");

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: "30d",
  });
};

const registerAdmin = async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;

    if (!name || !email || !phone || !password) {
      return res.status(400).json({ message: "Please enter all fields" });
    }

    const adminExists = await Admin.findOne({ $or: [{ email }, { phone }] });
    if (adminExists) {
      return res
        .status(400)
        .json({ message: "Admin with this email or phone already exists" });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const admin = await Admin.create({
      name,
      email,
      phone,
      password: hashedPassword,
    });

    if (admin) {
      res.status(201).json({
        _id: admin._id,
        name: admin.name,
        email: admin.email,
        phone: admin.phone,
        role: admin.role,
        token: generateToken(admin._id),
      });
    } else {
      res.status(400).json({ message: "Invalid admin data" });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const loginAdmin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email });

    if (admin && (await bcrypt.compare(password, admin.password))) {
      res.status(200).json({
        _id: admin._id,
        name: admin.name,
        email: admin.email,
        phone: admin.phone,
        role: admin.role,
        token: generateToken(admin._id),
      });
    } else {
      res.status(401).json({ message: "Invalid email or password" });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const sendOtp = async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return res.status(400).json({ message: "Mobile number is required" });
    }

    const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpiryTime = new Date(Date.now() + 10 * 60 * 1000);

    let admin = await Admin.findOne({ phone });

    if (!admin) {
      admin = new Admin({
        name: "Admin User",
        email: `${phone}@admin.com`,
        phone: phone,
        password: "defaultpassword123",
      });
    }

    admin.otp = generatedOtp;
    admin.otpExpires = otpExpiryTime;
    await admin.save();

    res.status(200).json({
      message: "OTP sent successfully",
      phone: phone,
      otp: generatedOtp,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const verifyOtp = async (req, res) => {
  try {
    const { phone, otp } = req.body;

    if (!phone || !otp) {
      return res
        .status(400)
        .json({ message: "Mobile number and OTP are required" });
    }

    const admin = await Admin.findOne({ phone });

    if (!admin) {
      return res.status(404).json({ message: "Mobile number not found" });
    }

    if (!admin.otp || admin.otp !== otp) {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    if (admin.otpExpires < new Date()) {
      return res.status(400).json({ message: "OTP has expired" });
    }

    admin.otp = null;
    admin.otpExpires = null;
    await admin.save();

    const token = generateToken(admin._id);

    res.status(200).json({
      message: "OTP verified successfully",
      token,
      admin: {
        _id: admin._id,
        name: admin.name,
        email: admin.email,
        phone: admin.phone,
        role: admin.role,
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Fixed to support protectAdmin (req.admin)
const getAdminProfile = async (req, res) => {
  try {
    const adminId = req.admin?._id || req.user?.id || req.user?._id;
    const admin = await Admin.findById(adminId).select("-password");
    if (!admin) {
      return res.status(404).json({ message: "Admin not found" });
    }
    res.status(200).json({ admin });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const createUserByAdmin = async (req, res) => {
  try {
    const { name, email, password, gender, age } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: "User already exists" });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      gender,
      age: Number(age),
    });

    res.status(201).json({ message: "User created successfully", user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.status(200).json({
      count: users.length,
      users,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById(id).select("-password");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Mass Assignment Protection with Allowlist
const updateUserByAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const ALLOWED_ADMIN_UPDATES = [
      "name",
      "email",
      "phone",
      "gender",
      "age",
      "bio",
      "jobTitle",
      "company",
      "school",
      "livingIn",
      "height",
      "interests",
      "lifestyle",
      "languages",
      "profilePic",
      "additionalPhotos",
      "isBanned",
      "isVerified",
      "walletBalance",
      "hostStatus",
      "isVerifiedHost",
    ];

    const updates = {};
    for (const key of ALLOWED_ADMIN_UPDATES) {
      if (req.body[key] !== undefined) {
        updates[key] = req.body[key];
      }
    }

    if (req.body.password) {
      const salt = await bcrypt.genSalt(10);
      updates.password = await bcrypt.hash(req.body.password, salt);
    }

    const updatedUser = await User.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    }).select("-password");

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({
      message: "User updated successfully",
      user: updatedUser,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deleteUserByAdmin = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById(id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    await User.findByIdAndDelete(id);
    res.status(200).json({ message: "User deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getDashboardStats = async (req, res) => {
  try {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    const [totalUsers, totalNewUsers, maleUsers, femaleUsers] =
      await Promise.all([
        User.countDocuments(),
        User.countDocuments({ createdAt: { $gte: thirtyDaysAgo } }),
        User.countDocuments({ gender: { $regex: /^male$/i } }),
        User.countDocuments({ gender: { $regex: /^female$/i } }),
      ]);

    res.status(200).json({
      totalUsers,
      totalNewUsers,
      maleUsers,
      femaleUsers,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const toggleUserStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById(id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    user.isBanned = !user.isBanned;
    await user.save();

    res.status(200).json({
      message: `User ${user.isBanned ? "banned" : "unbanned"} successfully`,
      isBanned: user.isBanned,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getUsersByGender = async (req, res) => {
  try {
    const { gender } = req.params;

    const users = await User.find({
      gender: { $regex: new RegExp(`^${gender}$`, "i") },
    }).select("-password");

    res.status(200).json({
      count: users.length,
      users,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const exportUsersToExcel = async (req, res) => {
  try {
    const users = await User.find().select("-password").lean();

    const workbook = new exceljs.Workbook();
    const worksheet = workbook.addWorksheet("Users");

    worksheet.columns = [
      { header: "ID", key: "_id", width: 30 },
      { header: "Name", key: "name", width: 25 },
      { header: "Email", key: "email", width: 30 },
      { header: "Gender", key: "gender", width: 15 },
      { header: "Age", key: "age", width: 10 },
      { header: "Status", key: "status", width: 15 },
      { header: "Created At", key: "createdAt", width: 25 },
    ];

    users.forEach((user) => {
      worksheet.addRow({
        _id: user._id ? user._id.toString() : "",
        name: user.name || "",
        email: user.email || "",
        gender: user.gender || "",
        age: user.age || "",
        status: user.isBanned ? "Banned" : "Active",
        createdAt: user.createdAt
          ? new Date(user.createdAt).toLocaleString()
          : "",
      });
    });

    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=users_data.xlsx",
    );

    await workbook.xlsx.write(res);
    res.status(200).end();
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getHelpRequests = async (req, res) => {
  try {
    const helpRequests = await Support.find()
      .populate("user", "name email")
      .sort({ createdAt: -1 });

    res.status(200).json({
      count: helpRequests.length,
      helpRequests,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const resolveHelpRequest = async (req, res) => {
  try {
    const { id } = req.params;

    const helpRequest = await Support.findByIdAndUpdate(
      id,
      { status: "resolved" },
      { new: true },
    );

    if (!helpRequest) {
      return res.status(404).json({ message: "Help request not found" });
    }
    res.status(200).json({
      message: "Help request resolved successfully",
      helpRequest,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getAllUserSubscriptions = async (req, res) => {
  try {
    const users = await User.find({
      "subscription.plan": { $exists: true, $ne: null },
    })
      .select("name email subscription")
      .populate("subscription.plan", "name subtitle prices")
      .sort({ "subscription.startDate": -1 });

    const subscriptions = users.map((user) => ({
      userId: user._id,
      userName: user.name,
      email: user.email,

      plan: user.subscription?.plan
        ? {
            id: user.subscription.plan._id,
            name: user.subscription.plan.name,
            subtitle: user.subscription.plan.subtitle,
            prices: user.subscription.plan.prices,
          }
        : null,

      billingCycle: user.subscription?.billingCycle,
      startDate: user.subscription?.startDate,
      endDate: user.subscription?.endDate,
      isActive: user.subscription?.isActive,
    }));

    res.status(200).json({
      success: true,
      count: subscriptions.length,
      subscriptions,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

const searchUser = async (req, res) => {
  try {
    const { search } = req.query;

    if (!search || !search.trim()) {
      return res.status(400).json({
        success: false,
        message: "Please enter a search value",
      });
    }

    const searchRegex = new RegExp(search.trim(), "i");

    const users = await User.find({
      $or: [
        { name: searchRegex },
        { email: searchRegex },
        { phone: searchRegex },
      ],
    })
      .select("-password -otp -refreshToken")
      .populate("subscription.plan", "name subtitle prices features isPopular");

    if (users.length === 0) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    res.status(200).json({
      success: true,
      count: users.length,
      users,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

const getUserStatsAndUnmatchedUsers = async (req, res) => {
  try {
    const [maleCount, femaleCount, unmatchedUsers] = await Promise.all([
      User.countDocuments({ gender: { $regex: /^male$/i } }),
      User.countDocuments({ gender: { $regex: /^female$/i } }),
      User.find({
        $or: [
          { matches: { $exists: false } },
          { matches: { $size: 0 } },
        ],
      })
        .select("name email gender age profilePic createdAt")
        .sort({ createdAt: -1 }),
    ]);

    const formattedUnmatchedUsers = unmatchedUsers.map((user) => ({
      _id: user._id,
      name: user.name,
      email: user.email,
      gender: user.gender,
      age: user.age,
      profilePic: user.profilePic,
      registeredDate: user.createdAt
        ? user.createdAt.toISOString().split("T")[0]
        : null,
      registeredTime: user.createdAt
        ? user.createdAt.toTimeString().split(" ")[0]
        : null,
      createdAt: user.createdAt,
    }));

    res.status(200).json({
      success: true,
      totalMaleUsers: maleCount,
      totalFemaleUsers: femaleCount,
      unmatchedUsersCount: formattedUnmatchedUsers.length,
      unmatchedUsers: formattedUnmatchedUsers,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Host Application Management
const getPendingHostApplications = async (req, res) => {
  try {
    const { status = "pending_review" } = req.query;
    const applications = await HostApplication.find({ status })
      .populate("applicant", "name email profilePic phone")
      .sort({ createdAt: -1 });

    return res
      .status(200)
      .json({ success: true, count: applications.length, data: applications });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// Secure signed document download (Brief v3)
const getHostApplicationDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const application = await HostApplication.findById(id);

    if (!application || !application.govIdImage) {
      return res
        .status(404)
        .json({ success: false, message: "ID Document not found." });
    }

    // Extract Cloudinary public_id safely
    const urlParts = application.govIdImage.split("/");
    const filenameWithExt = urlParts.slice(-2).join("/"); // folder/name.ext
    const publicId =
      filenameWithExt.substring(0, filenameWithExt.lastIndexOf(".")) ||
      filenameWithExt;

    // Generate short-lived (10 mins) signed URL
    const signedUrl = cloudinary.utils.private_download_url(publicId, "jpg", {
      resource_type: "image",
      type: "authenticated",
      expires_at: Math.floor(Date.now() / 1000) + 600,
    });

    return res.status(200).json({
      success: true,
      url: signedUrl || application.govIdImage,
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const approveHostApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const { adminNote } = req.body || {};

    const application = await HostApplication.findById(id);
    if (!application) {
      return res
        .status(404)
        .json({ success: false, message: "Application not found." });
    }

    const adminId = req.admin?._id || req.user?._id || req.user?.id || null;

    application.status = "approved";
    application.adminNote = adminNote || "";
    application.reviewedAt = new Date();
    application.reviewedBy = adminId;
    await application.save();

    await User.findByIdAndUpdate(application.applicant, {
      hostStatus: "approved",
      isVerifiedHost: true,
    });

    return res
      .status(200)
      .json({ success: true, message: "Host approved.", data: application });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

const rejectHostApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const { adminNote } = req.body || {};

    const application = await HostApplication.findById(id);
    if (!application) {
      return res
        .status(404)
        .json({ success: false, message: "Application not found." });
    }

    const adminId = req.admin?._id || req.user?._id || req.user?.id || null;

    application.status = "rejected";
    application.adminNote = adminNote || "";
    application.reviewedAt = new Date();
    application.reviewedBy = adminId;
    await application.save();

    await User.findByIdAndUpdate(application.applicant, {
      hostStatus: "rejected",
      isVerifiedHost: false,
    });

    return res
      .status(200)
      .json({ success: true, message: "Host rejected.", data: application });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  registerAdmin,
  loginAdmin,
  sendOtp,
  verifyOtp,
  getAdminProfile,
  createUserByAdmin,
  getAllUsers,
  getUserById,
  updateUserByAdmin,
  deleteUserByAdmin,
  getDashboardStats,
  toggleUserStatus,
  getUsersByGender,
  exportUsersToExcel,
  getHelpRequests,
  resolveHelpRequest,
  getAllUserSubscriptions,
  searchUser,
  getUserStatsAndUnmatchedUsers,
  getPendingHostApplications,
  getHostApplicationDocument,
  approveHostApplication,
  rejectHostApplication,
};